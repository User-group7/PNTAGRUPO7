﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AppHardware.Migrations
{
    public partial class ForeignKeys : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Productos",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "Apellido",
                table: "Registros");

            migrationBuilder.DropColumn(
                name: "Nombre",
                table: "Registros");

            migrationBuilder.DropColumn(
                name: "ProductName",
                table: "Registros");

            migrationBuilder.DropColumn(
                name: "ProductId",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "ModelNo",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "ProductDescription",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "ProductName",
                table: "Productos");

            migrationBuilder.AddColumn<int>(
                name: "ProductoId",
                table: "Registros",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "UsuarioId",
                table: "Registros",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProductoId",
                table: "Productos",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<string>(
                name: "ModeloNombre",
                table: "Productos",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProductoDescripcion",
                table: "Productos",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProductoNombre",
                table: "Productos",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Productos",
                table: "Productos",
                column: "ProductoId");

            migrationBuilder.CreateTable(
                name: "Usuarios",
                columns: table => new
                {
                    UsuarioId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(nullable: true),
                    Apellido = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Usuarios", x => x.UsuarioId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Registros_ProductoId",
                table: "Registros",
                column: "ProductoId");

            migrationBuilder.CreateIndex(
                name: "IX_Registros_UsuarioId",
                table: "Registros",
                column: "UsuarioId");

            migrationBuilder.AddForeignKey(
                name: "FK_Registros_Productos_ProductoId",
                table: "Registros",
                column: "ProductoId",
                principalTable: "Productos",
                principalColumn: "ProductoId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Registros_Usuarios_UsuarioId",
                table: "Registros",
                column: "UsuarioId",
                principalTable: "Usuarios",
                principalColumn: "UsuarioId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Registros_Productos_ProductoId",
                table: "Registros");

            migrationBuilder.DropForeignKey(
                name: "FK_Registros_Usuarios_UsuarioId",
                table: "Registros");

            migrationBuilder.DropTable(
                name: "Usuarios");

            migrationBuilder.DropIndex(
                name: "IX_Registros_ProductoId",
                table: "Registros");

            migrationBuilder.DropIndex(
                name: "IX_Registros_UsuarioId",
                table: "Registros");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Productos",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "ProductoId",
                table: "Registros");

            migrationBuilder.DropColumn(
                name: "UsuarioId",
                table: "Registros");

            migrationBuilder.DropColumn(
                name: "ProductoId",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "ModeloNombre",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "ProductoDescripcion",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "ProductoNombre",
                table: "Productos");

            migrationBuilder.AddColumn<string>(
                name: "Apellido",
                table: "Registros",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Nombre",
                table: "Registros",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProductName",
                table: "Registros",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ProductId",
                table: "Productos",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<string>(
                name: "ModelNo",
                table: "Productos",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProductDescription",
                table: "Productos",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProductName",
                table: "Productos",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_Productos",
                table: "Productos",
                column: "ProductId");
        }
    }
}
