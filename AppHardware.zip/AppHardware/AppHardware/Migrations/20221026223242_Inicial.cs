﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AppHardware.Migrations
{
    public partial class Inicial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Productos_Category_CatId1",
                table: "Productos");

            migrationBuilder.DropTable(
                name: "Category");

            migrationBuilder.DropIndex(
                name: "IX_Productos_CatId1",
                table: "Productos");

            migrationBuilder.DropColumn(
                name: "CatId1",
                table: "Productos");

            migrationBuilder.AddColumn<int>(
                name: "CatId",
                table: "Productos",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CatId",
                table: "Productos");

            migrationBuilder.AddColumn<int>(
                name: "CatId1",
                table: "Productos",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Category",
                columns: table => new
                {
                    CatId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CatName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Category", x => x.CatId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Productos_CatId1",
                table: "Productos",
                column: "CatId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Productos_Category_CatId1",
                table: "Productos",
                column: "CatId1",
                principalTable: "Category",
                principalColumn: "CatId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
