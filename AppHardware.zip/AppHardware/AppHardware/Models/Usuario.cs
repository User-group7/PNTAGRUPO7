﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AppHardware.Models
{
    public class Usuario
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int RegistroId { get; set; }
        [Display(Name = "Nombre")]
        public String Nombre { get; set; }
        [Display(Name = "Apellido")]
        public String Apellido { get; set; }
    }
}
